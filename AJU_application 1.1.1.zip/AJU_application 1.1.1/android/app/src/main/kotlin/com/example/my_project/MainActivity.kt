package com.flutterflow.ajuapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
